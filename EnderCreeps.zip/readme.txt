Current Version of mod: 1.4.5

How to install:
>> Go to C:\Users\[NAME]\AppData\Roaming\.minecraft\bin\minecraft.jar
>> Remove META-INF folder in minecraft.jar 
>> Install Modloader inside minecraft.jar (Located here: http://www.minecraftforum.net/topic/75440-v145-risugamis-mods-updated/)
>> Run Minecraft once.
>> Exit Minecraft.
>> Go to C:\Users\[NAME]\AppData\Roaming\.minecraft\mods
>> Place EnderCreeps.zip in the folder/
>> Enjoy!